import os
import torch
import joblib
import numpy as np
import librosa
import streamlit as st

# Import the model architecture
from model import CNNLSTM_AgeGender

# Age Mapping
age_mapping = {
    0: 'teens',
    1: 'twenties',
    2: 'thirties',
    3: 'fourties',
    4: 'fifties',
    5: 'sixties'
}


# Setup
st.title("Voice-Based Gender and Age Prediction")
st.markdown("Upload a `.wav` audio file (max 16MB) to predict speaker's gender and age group.")

# Load model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = CNNLSTM_AgeGender().to(device)
model.load_state_dict(torch.load('model_weights.pth', map_location=device))
model.eval()

# Load scaler
scaler = joblib.load('scaler.pkl')

def extract_features(file_path):
    try:
        y, sr = librosa.load(file_path, sr=16000)
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        chroma = librosa.feature.chroma_stft(y=y, sr=sr)
        contrast = librosa.feature.spectral_contrast(y=y, sr=sr)
        tonnetz = librosa.feature.tonnetz(y=librosa.effects.harmonic(y), sr=sr)

        features = np.concatenate([
            np.mean(mfcc, axis=1),
            np.mean(chroma, axis=1),
            np.mean(contrast, axis=1),
            np.mean(tonnetz, axis=1)
        ])
        return features
    except Exception as e:
        st.error(f"Feature extraction failed: {e}")
        return None

def predict_from_audio(file):
    # Save file temporarily
    with open("temp.wav", "wb") as f:
        f.write(file.getbuffer())

    features = extract_features("temp.wav")
    os.remove("temp.wav")

    if features is None:
        return None, None

    scaled = scaler.transform(features.reshape(1, -1))  # Shape: (1, 38)
    input_tensor = torch.tensor(scaled, dtype=torch.float32).unsqueeze(1).to(device)  # Shape: (1, 1, 38)

    with torch.no_grad():
        pred_gender, pred_age_logits = model(input_tensor)
        gender = 'Male' if pred_gender.item() > 0.5 else 'Female'
        age_class = torch.argmax(pred_age_logits, dim=1).item()
        age_label = age_mapping.get(age_class, 'Unknown')

    return gender, age_label

# Upload audio
audio_file = st.file_uploader("Choose a .wav file", type=["wav"])

if audio_file:
    st.audio(audio_file, format='audio/wav')
    if st.button("Predict"):
        gender, age = predict_from_audio(audio_file)
        if gender and age:
            st.success(f"**Gender**: {gender}")
            st.success(f"**Predicted Age Group**: {age}")
        else:
            st.error("Failed to process the audio file.")
