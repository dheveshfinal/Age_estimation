import os
import librosa
import numpy as np
import pandas as pd
from tqdm import tqdm

def extract_features(file_path):
    """
    Extracts various audio features from a given .wav file using librosa.
    """
    try:
        y, sr = librosa.load(file_path, sr=16000)
        
        # Extract features
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        mfcc_mean = np.mean(mfcc, axis=1)
        
        chroma = librosa.feature.chroma_stft(y=y, sr=sr)
        chroma_mean = np.mean(chroma, axis=1)

        spec_contrast = librosa.feature.spectral_contrast(y=y, sr=sr)
        spec_contrast_mean = np.mean(spec_contrast, axis=1)

        tonnetz = librosa.feature.tonnetz(y=librosa.effects.harmonic(y), sr=sr)
        tonnetz_mean = np.mean(tonnetz, axis=1)

        # Combine all features
        features = np.concatenate((mfcc_mean, chroma_mean, spec_contrast_mean, tonnetz_mean))
        return features
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return None

def prepare_dataset(audio_folder, metadata_tsv, output_csv="final_dataset.csv"):
    """
    Combines extracted features with metadata and exports a single CSV file.
    """
    # Read the metadata
    df = pd.read_csv(metadata_tsv, sep='\t')

    # Filter out rows with missing age or gender
    df = df[df['age'].notnull() & df['gender'].notnull()]

    data = []
    for _, row in tqdm(df.iterrows(), total=len(df), desc="Processing audio"):
        file_name = row['path'].replace('.mp3', '.wav')  # converted format
        file_path = os.path.join(audio_folder, file_name)

        if os.path.exists(file_path):
            features = extract_features(file_path)
            if features is not None:
                record = {
                    'client_id': row['client_id'],
                    'gender': row['gender'],
                    'age': row['age'],
                }
                for i, f in enumerate(features):
                    record[f'feature_{i}'] = f
                data.append(record)
        else:
            print(f"File missing: {file_name}")

    # Save to CSV
    dataset = pd.DataFrame(data)
    dataset.to_csv(output_csv, index=False)
    print(f"\nDataset saved to {output_csv} with shape {dataset.shape}")

# Usage
if __name__ == "__main__":
    audio_folder = "Dataset"              # Folder with .wav files
    metadata_tsv = "metadata.tsv"            # Path to metadata file
    prepare_dataset(audio_folder, metadata_tsv)
