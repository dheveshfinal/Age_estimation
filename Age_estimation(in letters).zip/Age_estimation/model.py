import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np

# Age Mapping
age_mapping = {
    'sixties': 5,
        'fifties': 4,
        'fourties': 3,
        'thirties': 2,
        'twenties': 1,
        'teens': 0
}

# Dataset class
class AudioFeatureDataset(Dataset):
    def __init__(self, X, gender, age):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.gender = torch.tensor(gender, dtype=torch.float32)
        self.age = torch.tensor(age, dtype=torch.long)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        feature = self.X[idx].unsqueeze(0)  # Shape: (1, 38)
        return feature, self.gender[idx], self.age[idx]

# Model class
class CNNLSTM_AgeGender(nn.Module):
    def __init__(self):
        super(CNNLSTM_AgeGender, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=64, kernel_size=3)
        self.pool = nn.MaxPool1d(2)
        self.lstm = nn.LSTM(input_size=64, hidden_size=64, batch_first=True)
        self.fc_gender = nn.Linear(64, 1)
        self.fc_age = nn.Linear(64, 6)

    def forward(self, x):
        x = self.conv1(x)
        x = self.pool(x)
        x = x.transpose(1, 2)  # For LSTM: (batch, seq_len, features)
        _, (hn, _) = self.lstm(x)
        x = hn[-1]  # Final hidden state
        gender = torch.sigmoid(self.fc_gender(x))
        age_logits = self.fc_age(x)
        return gender, age_logits

# Load data
def load_data(file_path='preprocessed_data.csv'):
    df = pd.read_csv(file_path)
    print(f"[INFO] Data loaded from {file_path}")
    return df

# Training function
def train_model():
    df = load_data()
    X = df[[f'feature_{i}' for i in range(38)]].values
    y_gender = df['gender'].values
    y_age = df['age'].values

    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    X_train, X_test, yg_train, yg_test, ya_train, ya_test = train_test_split(
        X, y_gender, y_age, test_size=0.2, random_state=42
    )

    train_loader = DataLoader(AudioFeatureDataset(X_train, yg_train, ya_train), batch_size=32, shuffle=True)
    test_loader = DataLoader(AudioFeatureDataset(X_test, yg_test, ya_test), batch_size=32, shuffle=False)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = CNNLSTM_AgeGender().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    gender_loss_fn = nn.BCELoss()
    age_loss_fn = nn.CrossEntropyLoss()
    alpha = 0.5

    for epoch in range(25):
        model.train()
        total_loss = 0.0

        for features, gender_labels, age_labels in train_loader:
            features = features.to(device)
            gender_labels = gender_labels.to(device)
            age_labels = age_labels.to(device)

            optimizer.zero_grad()
            pred_gender, pred_age_logits = model(features)

            loss_gender = gender_loss_fn(pred_gender.squeeze(), gender_labels)
            loss_age = age_loss_fn(pred_age_logits, age_labels)
            loss = loss_gender + alpha * loss_age
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        print(f"Epoch {epoch+1}, Loss: {total_loss / len(train_loader):.4f}")

    torch.save(model.state_dict(), "model_weights.pth")
    print("[INFO] Model saved to model_weights.pth")
    return model, test_loader, X_test, yg_test, ya_test, device, gender_loss_fn, age_loss_fn, alpha

# Evaluation function
def evaluate_model(model, test_loader, X_test, yg_test, ya_test, device, gender_loss_fn, age_loss_fn, alpha):
    model.eval()
    total_loss = 0.0
    correct_gender = 0
    total_gender = 0
    correct_age = 0
    total_age = 0

    with torch.no_grad():
        for features, gender_labels, age_labels in test_loader:
            if features.ndim == 2:
                features = features.unsqueeze(1)
            features = features.to(device)
            gender_labels = gender_labels.to(device)
            age_labels = age_labels.to(device)

            pred_gender, pred_age_logits = model(features)
            loss_gender = gender_loss_fn(pred_gender.squeeze(), gender_labels)
            loss_age = age_loss_fn(pred_age_logits, age_labels)
            loss = loss_gender + alpha * loss_age
            total_loss += loss.item()

            predicted_gender = (pred_gender > 0.5).float()
            correct_gender += (predicted_gender.squeeze() == gender_labels).sum().item()
            total_gender += gender_labels.size(0)

            predicted_age_class = pred_age_logits.argmax(dim=1)
            correct_age += (predicted_age_class == age_labels).sum().item()
            total_age += age_labels.size(0)

    test_loss = total_loss / len(test_loader)
    gender_accuracy = 100. * correct_gender / total_gender
    age_accuracy = 100. * correct_age / total_age

    print(f"[RESULTS] Test Loss: {test_loss:.4f}")
    print(f"[RESULTS] Gender Accuracy: {gender_accuracy:.2f}%")
    print(f"[RESULTS] Age Classification Accuracy: {age_accuracy:.2f}%")

# Predict single sample
def predict_sample(model, X_test, index, device):
    sample = torch.tensor(X_test[index], dtype=torch.float32).unsqueeze(0).unsqueeze(1).to(device)
    model.eval()
    with torch.no_grad():
        pred_gender, pred_age_logits = model(sample)
        predicted_gender = (pred_gender > 0.5).float().item()
        predicted_age_class = torch.argmax(pred_age_logits, dim=1).item()
        reverse_age_map = {v: k for k, v in age_mapping.items()}

        print(f"[SAMPLE {index}] Predicted Gender: {'Male' if predicted_gender == 1 else 'Female'}")
        print(f"[SAMPLE {index}] Predicted Age Class: {reverse_age_map[predicted_age_class]}")

# Main
if __name__ == "__main__":
    model, test_loader, X_test, yg_test, ya_test, device, gender_loss_fn, age_loss_fn, alpha = train_model()
    evaluate_model(model, test_loader, X_test, yg_test, ya_test, device, gender_loss_fn, age_loss_fn, alpha)
    predict_sample(model, X_test, index=0, device=device)
