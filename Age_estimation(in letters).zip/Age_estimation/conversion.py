import os
import subprocess
from tqdm import tqdm

def convert_mp3_folder(input_folder, output_folder):
    """
    Converts all .mp3 files in the input_folder to .wav format using ffmpeg.
    Output files are saved in the output_folder.
    """
    print(f"Looking for folder: {os.path.abspath(input_folder)}")

    # Check if the input folder exists
    if not os.path.exists(input_folder):
        print(f"Input folder doesn't exist. Exiting.")
        return

    print(f"Converting audio files...")

    # Create the output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    files_converted = 0
    # List all files in the input folder for debugging
    print("Files in input folder:")
    for file_name in os.listdir(input_folder):
        print(file_name)  # Print each file to check extensions

    # Loop through all files in the input folder
    for file_name in tqdm(os.listdir(input_folder), desc="Converting files"):
        if file_name.endswith('.mp3'):  # Now look for .mp3 files
            input_file_path = os.path.join(input_folder, file_name)
            output_file_name = file_name.replace('.mp3', '.wav')
            output_file_path = os.path.join(output_folder, output_file_name)

            try:
                # Check if file is not empty
                if os.path.getsize(input_file_path) > 0:
                    # Convert .mp3 to .wav using ffmpeg
                    subprocess.run(
                        ['ffmpeg', '-i', input_file_path, '-ar', '16000', '-ac', '1', output_file_path],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        check=True
                    )
                    files_converted += 1
                else:
                    print(f"File is empty: {file_name}")
            except Exception as e:
                print(f"Error converting {file_name}: {e}")

    print(f"Total files converted: {files_converted}")

# Main execution
if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python conversion.py <input_folder> <output_folder>")
    else:
        input_folder = sys.argv[1]
        output_folder = sys.argv[2]
        convert_mp3_folder(input_folder, output_folder)
