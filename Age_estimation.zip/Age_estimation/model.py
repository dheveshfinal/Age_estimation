import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np
import os
import joblib


# Dataset class
class AudioFeatureDataset(Dataset):
    def __init__(self, X, gender, age):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.gender = torch.tensor(gender, dtype=torch.float32)
        self.age = torch.tensor(age, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        feature = self.X[idx].unsqueeze(0)  # (1, 38)
        return feature, self.gender[idx], self.age[idx]

# Model class
class CNNLSTM_AgeGender(nn.Module):
    def __init__(self):
        super(CNNLSTM_AgeGender, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=64, kernel_size=3)
        self.pool = nn.MaxPool1d(2)
        self.lstm = nn.LSTM(input_size=64, hidden_size=64, batch_first=True)
        self.fc_gender = nn.Linear(64, 1)
        self.fc_age = nn.Linear(64, 1)

    def forward(self, x):
        x = self.conv1(x)
        x = self.pool(x)
        x = x.transpose(1, 2)  # Prepare for LSTM
        _, (hn, _) = self.lstm(x)
        x = hn[-1]
        gender = torch.sigmoid(self.fc_gender(x))
        age = self.fc_age(x)
        return gender, age

def load_data(file_path='preprocessed_data.csv'):
    df = pd.read_csv(file_path)
    print(f"[INFO] Data loaded from {file_path}")
    return df

def train_model():
    # Load and preprocess data
    df = load_data()
    X = df[[f'feature_{i}' for i in range(38)]].values
    y_gender = df['gender'].values
    y_age = df['age'].values

    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    joblib.dump(scaler, "scaler.pkl")  # Save the scaler

    X_train, X_test, yg_train, yg_test, ya_train, ya_test = train_test_split(
        X, y_gender, y_age, test_size=0.2, random_state=42
    )

    train_loader = DataLoader(AudioFeatureDataset(X_train, yg_train, ya_train), batch_size=32, shuffle=True)
    test_loader = DataLoader(AudioFeatureDataset(X_test, yg_test, ya_test), batch_size=32, shuffle=False)

    # Model setup
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = CNNLSTM_AgeGender().to(device)

    # Load pre-trained weights if available
    if os.path.exists("model_weights.pth"):
        model.load_state_dict(torch.load("model_weights.pth", map_location=device))
        print("[INFO] Loaded pre-trained model weights.")
    else:
        print("[INFO] No pre-trained weights found. Training from scratch.")
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        gender_loss_fn = nn.BCELoss()
        age_loss_fn = nn.MSELoss()
        alpha = 0.5  # Weight for age loss

        # Training loop
        for epoch in range(50):
            model.train()
            total_loss = 0

            for features, gender_labels, age_labels in train_loader:
                features = features.to(device)
                gender_labels = gender_labels.to(device)
                age_labels = age_labels.to(device)

                optimizer.zero_grad()
                pred_gender, pred_age = model(features)

                loss_gender = gender_loss_fn(pred_gender.squeeze(), gender_labels)
                loss_age = age_loss_fn(pred_age.squeeze(), age_labels)
                loss = loss_gender + alpha * loss_age
                loss.backward()
                optimizer.step()

                total_loss += loss.item()

            print(f"Epoch {epoch+1}, Loss: {total_loss / len(train_loader):.4f}")

        # Save final model
        torch.save(model.state_dict(), "model_weights.pth")
        print("[INFO] Model saved to model_weights.pth")

    return model, test_loader, X_test, device, nn.BCELoss(), nn.MSELoss(), 0.5

def evaluate_model(model, test_loader, X_test, device, gender_loss_fn, age_loss_fn, alpha):
    model.eval()
    total_loss = 0.0
    correct_gender = 0
    total_gender = 0
    gender_preds, age_preds = [], []
    gender_true, age_true = [], []

    with torch.no_grad():
        for features, gender_labels, age_labels in test_loader:
            if features.ndim == 2:
                features = features.unsqueeze(1)
            features = features.to(device)
            gender_labels = gender_labels.float().to(device)
            age_labels = age_labels.to(device)

            pred_gender, pred_age = model(features)
            pred_gender = pred_gender.squeeze()
            pred_age = pred_age.squeeze()

            loss_gender = gender_loss_fn(pred_gender, gender_labels)
            loss_age = age_loss_fn(pred_age, age_labels)
            loss = loss_gender + alpha * loss_age
            total_loss += loss.item()

            predicted_gender = (pred_gender > 0.5).float()
            correct_gender += (predicted_gender == gender_labels).sum().item()
            total_gender += gender_labels.size(0)

            gender_preds.extend(predicted_gender.cpu().numpy())
            age_preds.extend(pred_age.cpu().numpy())
            gender_true.extend(gender_labels.cpu().numpy())
            age_true.extend(age_labels.cpu().numpy())

    test_loss = total_loss / len(test_loader)
    gender_accuracy = 100. * correct_gender / total_gender
    rmse = np.sqrt(((np.array(age_preds) - np.array(age_true)) ** 2).mean())

    print(f"[RESULTS] Test Loss: {test_loss:.4f}")
    print(f"[RESULTS] Gender Accuracy: {gender_accuracy:.2f}%")
    print(f"[RESULTS] Age RMSE: {rmse:.2f} years")

def predict_sample(model, X_test, index, device):
    if index >= len(X_test):
        print(f"[ERROR] Index {index} is out of range.")
        return

    sample = torch.tensor(X_test[index], dtype=torch.float32).unsqueeze(0).unsqueeze(1).to(device)
    pred_gender, pred_age = model(sample)
    predicted_gender = (pred_gender > 0.5).float().item()
    predicted_age = pred_age.item()

    print(f"[SAMPLE {index}] Predicted Gender: {'Male' if predicted_gender == 1 else 'Female'}")
    print(f"[SAMPLE {index}] Predicted Age: {predicted_age:.2f} years")

if __name__ == "__main__":
    model, test_loader, X_test, device, gender_loss_fn, age_loss_fn, alpha = train_model()
    evaluate_model(model, test_loader, X_test, device, gender_loss_fn, age_loss_fn, alpha)
    predict_sample(model, X_test, index=0, device=device)
