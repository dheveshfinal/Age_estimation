import pandas as pd
import argparse
import sys
from sklearn.model_selection import train_test_split

# Function to load the dataset
def load_dataset(file_path):
    try:
        # Load the dataset from the given file path
        df = pd.read_csv(file_path)
        print(f"Dataset loaded successfully from {file_path}")
        return df
    except Exception as e:
        print(f"Error loading the dataset: {e}")
        sys.exit(1)

# Main function
def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Load a dataset CSV file")
    parser.add_argument('dataset', type=str, help="Path to the dataset CSV file")
    
    # Parse arguments
    args = parser.parse_args()

    # Load the dataset
    df = load_dataset(args.dataset)

    # Encoding mappings
    age_mapping = {
        'fourties': 40,
        'sixties': 60,
        'fifties': 50,
        'thirties': 30,
        'twenties': 20,
        'teens': 18
    }
    gender_mapping = {
        'female_feminine': 0,
        'male_masculine': 1
    }

    # Apply the mappings to the DataFrame
    df['age'] = df['age'].map(age_mapping)
    df['gender'] = df['gender'].map(gender_mapping)
    
    # Drop rows with NaN values and reset index
    df_sampled = df.dropna().reset_index(drop=True)
    
    # Drop client_id column and retain numeric columns
    df_numeric = df_sampled.drop(columns=['client_id'])
    
    # Save the preprocessed data to a file (e.g., CSV or pickle)
    df_numeric.to_csv('preprocessed_data.csv', index=False)
    print("Preprocessing is done, and the data is saved as 'preprocessed_data.csv'.")

# Ensure the script is run directly
if __name__ == "__main__":
    main()
