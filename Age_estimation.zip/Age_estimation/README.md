# Age_estimation
  pip install -r requirements.txt

# Feature extraction
## MFCC (Mel-Frequency Cepstral Coefficients) – 13 values
  What it captures  The shape of the vocal tract – essentially how the sound is formed.
  Why it's useful: Core feature for speaker identification, emotion detection, and speech recognition.
  Helps distinguish age (vocal tract changes over time) and gender (pitch/timbre differences).
  mfcc_mean = np.mean(mfcc, axis=1) gives average values across time frames.
  
## Chroma STFT (Short-Time Fourier Transform) – 12 values
  What it captures: The distribution of energy among the 12 different pitch classes (like piano keys: C, C#, D...).
  Why it's useful: Sensitive to harmonic content and pitch – which can vary based on vocal style, gender, and age.
  Good for analyzing tonal characteristics.

## Spectral Contrast – 7 values
  What it captures: The difference between peaks and valleys in the sound spectrum.
  Why it's useful: Helps distinguish between strong and weak harmonics.
  Indicates brightness or richness of the voice, which differs with age and gender.
  
## Tonnetz (Tonal Centroid Features) – 6 values
  What it captures: Tonal relationships like major/minor harmony in speech.
  Why it's useful: Particularly helpful for emotion, language rhythm, and intonation – which can vary with gender/age.
  Think of it like the “musicality” or melodic flow of the voice.

## Commands to run the model
  After downloading all the files 
  python model.py 
