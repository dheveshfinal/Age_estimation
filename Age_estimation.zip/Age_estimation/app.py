import os
import torch
import joblib
import numpy as np
import librosa
from flask import Flask, request, render_template, jsonify
from werkzeug.utils import secure_filename

# Import the model architecture
from model import CNNLSTM_AgeGender

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['ALLOWED_EXTENSIONS'] = {'wav'}

# Create uploads folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Load the trained model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = CNNLSTM_AgeGender().to(device)
model.load_state_dict(torch.load('model_weights.pth', map_location=device))
model.eval()

# Load the scaler
scaler = joblib.load('scaler.pkl')

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def extract_features(file_path):
    """
    Extracts various audio features from a given .wav file using librosa.
    """
    try:
        y, sr = librosa.load(file_path, sr=16000)
        
        # Extract features
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        mfcc_mean = np.mean(mfcc, axis=1)
        
        chroma = librosa.feature.chroma_stft(y=y, sr=sr)
        chroma_mean = np.mean(chroma, axis=1)
        
        spec_contrast = librosa.feature.spectral_contrast(y=y, sr=sr)
        spec_contrast_mean = np.mean(spec_contrast, axis=1)
        
        tonnetz = librosa.feature.tonnetz(y=librosa.effects.harmonic(y), sr=sr)
        tonnetz_mean = np.mean(tonnetz, axis=1)
        
        # Combine all features
        features = np.concatenate((mfcc_mean, chroma_mean, spec_contrast_mean, tonnetz_mean))
        return features
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return None

def process_audio_file(file_path):
    """
    Process audio file and prepare features for model prediction
    """
    features = extract_features(file_path)
    
    if features is None:
        return None
    
    # Scale the features using the saved scaler
    scaled_features = scaler.transform(features.reshape(1, -1))
    
    return scaled_features

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Extract features from the audio file
        features = process_audio_file(filepath)
        
        if features is None:
            return jsonify({'error': 'Failed to extract features from the audio'})
        
        # Prepare features for model input
        features_tensor = torch.tensor(features, dtype=torch.float32).unsqueeze(0).to(device)
        
        # Make prediction
        with torch.no_grad():
            pred_gender, pred_age = model(features_tensor)
            gender = 'Male' if pred_gender.item() > 0.5 else 'Female'
            age = round(pred_age.item(), 1)
        
        # Clean up the uploaded file
        try:
            os.remove(filepath)
        except:
            pass
        
        return jsonify({
            'gender': gender,
            'age': age
        })
    
    return jsonify({'error': 'File type not allowed'})

if __name__ == '__main__':
    app.run(debug=True)